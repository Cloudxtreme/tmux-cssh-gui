#!/usr/bin/env python

def error(message):
    output('Error: '+message)
# End def

def output(message):
    print message
# End def