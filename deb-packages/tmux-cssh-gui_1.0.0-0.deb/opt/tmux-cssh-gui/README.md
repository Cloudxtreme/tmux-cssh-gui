# TMUX-CSSH-GUI
_A simple, useful GUI on top of tmux-cssh._

## Python requirements

Following python-libs are required, used and imported:

* argparse
* ConfigParser
* gtk, gtk.glade
* os
* re
* shlex
* subprocess

