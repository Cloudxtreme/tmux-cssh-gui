#!/usr/bin/env python

# Import gtk-environment for handling the execution
import gtk

# Import class for main window
from gui.main import TMUXCSSHGUI

tmuxcsshgui= TMUXCSSHGUI()
gtk.main()
exit(0)

